//: Playground - Juego de Memoria - ajsilesl

import UIKit

for num in 0...100{
    if (num != 0) {
        if (num % 5) == 0 {
            print("# \(num) \t\t Bingo!!!")
        }else if (num % 2) == 0 {
            print("# \(num) \t\t Par!!!")
        }else{
            print("# \(num) \t\t Impar!!!")
        }
    }
}
